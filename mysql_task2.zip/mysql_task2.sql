-- Create the 'employee' table
CREATE TABLE employee (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(20)
);

-- Create the 'employee_job_status' table
CREATE TABLE employee_job_status (
    id INT AUTO_INCREMENT PRIMARY KEY,
    empId INT,
    jobsts ENUM('complete', 'cancel', 'pending'),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (empId) REFERENCES employee(id)
);

-- Insert 5 employees into the 'employee' table
INSERT INTO employee (name, email, phone)
VALUES
    ('John Doe', 'john.doe@example.com', '555-555-5555'),
    ('Jane Smith', 'jane.smith@example.com', '555-555-5556'),
    ('Alice Johnson', 'alice.johnson@example.com', '555-555-5557'),
    ('Bob Brown', 'bob.brown@example.com', '555-555-5558'),
    ('Eve Wilson', 'eve.wilson@example.com', '555-555-5559');

-- Add job statuses for employees
INSERT INTO employee_job_status (empId, jobsts)
SELECT id, 'complete' FROM employee;
INSERT INTO employee_job_status (empId, jobsts)
SELECT id, 'cancel' FROM employee;
INSERT INTO employee_job_status (empId, jobsts)
SELECT id, 'pending' FROM employee;


-- Get the last job status for each employee
SELECT e.id, e.name, e.email, e.phone, ej.jobsts AS job_status
FROM employee e
JOIN (
    SELECT empId, jobsts
    FROM employee_job_status
    ORDER BY timestamp DESC
) ej ON e.id = ej.empId
GROUP BY e.id;
